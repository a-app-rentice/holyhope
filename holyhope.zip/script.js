const verseElement = document.getElementById('verse');
const referenceElement = document.getElementById('reference');
const regenerateButton = document.getElementById('regenerate');
const favoriteButton = document.getElementById('favorite');
const favoritesList = document.getElementById('favorites-list');
const homePage = document.getElementById('home-page');
const favoritesPage = document.getElementById('favorites-page');
const homeTab = document.getElementById('home-tab');
const favoritesTab = document.getElementById('favorites-tab');
const noFavoritesMessage = document.getElementById('no-favorites-message');

let currentVerse = '';
let currentReference = '';
let favorites = [];

// Fetch Bible Verse using Gemini API
async function fetchVerse() {
  const apiKey = 'AIzaSyAhH0xsR3E5l8JWTmM_8MPjncXPZuM_4lI';
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: 'Give me a random Malayalam Bible verse.' }] }]
    })
  });
  const data = await response.json();
  const verseText = data.candidates[0].content.parts[0].text;
  const [verse, reference] = verseText.split('—');
  currentVerse = verse.trim();
  currentReference = reference ? reference.trim() : '';

  // Smooth Fade-In Animation for New Verse
  const quoteBox = document.getElementById('quote-box');
  quoteBox.style.opacity = 0;
  setTimeout(() => {
    verseElement.textContent = currentVerse;
    referenceElement.textContent = `— ${currentReference}`;
    quoteBox.style.opacity = 1;

    // Check if the verse is already favorited
    const isFavorited = favorites.some(fav => fav.verse === currentVerse && fav.reference === currentReference);
    favoriteButton.classList.toggle('active', isFavorited);
  }, 300);
}

// Add or Remove from Favorites
function toggleFavorite(button, verse, reference) {
  const index = favorites.findIndex(fav => fav.verse === verse && fav.reference === reference);

  if (index === -1) {
    // Add to Favorites
    favorites.push({ verse, reference });
    button.classList.add('active');
  } else {
    // Remove from Favorites
    favorites.splice(index, 1);
    button.classList.remove('active');
  }

  updateFavoritesList();
}

// Update Favorites List
function updateFavoritesList() {
  favoritesList.innerHTML = '';

  if (favorites.length === 0) {
    noFavoritesMessage.style.display = 'block'; // Show "No favorites" message
  } else {
    noFavoritesMessage.style.display = 'none'; // Hide "No favorites" message
  }

  favorites.forEach(({ verse, reference }) => {
    const listItem = document.createElement('li');
    const quoteBox = document.createElement('div');
    quoteBox.classList.add('quote-box');
    quoteBox.innerHTML = `
      <button class="favorite-btn active"><i class="fas fa-heart"></i></button>
      <p>${verse}</p>
      <small class="verse-reference">— ${reference}</small>
    `;
    listItem.appendChild(quoteBox);

    // Add Event Listener to Remove from Favorites
    const heartButton = quoteBox.querySelector('.favorite-btn');
    heartButton.addEventListener('click', () => {
      // Apply Vanishing Animation
      quoteBox.classList.add('fade-out');
      setTimeout(() => {
        toggleFavorite(heartButton, verse, reference);
      }, 500); // Wait for Animation to Finish
    });

    favoritesList.prepend(listItem);
  });
}

// Switch Pages
function showHomePage() {
  homePage.style.display = 'block';
  favoritesPage.style.display = 'none';
  homeTab.classList.add('active');
  favoritesTab.classList.remove('active');
}

function showFavoritesPage() {
  homePage.style.display = 'none';
  favoritesPage.style.display = 'block';
  favoritesTab.classList.add('active');
  homeTab.classList.remove('active');
}

// Event Listeners
regenerateButton.addEventListener('click', () => {
  regenerateButton.classList.add('active');
  fetchVerse();
  setTimeout(() => regenerateButton.classList.remove('active'), 500);
});

favoriteButton.addEventListener('click', () => {
  toggleFavorite(favoriteButton, currentVerse, currentReference);
});

homeTab.addEventListener('click', showHomePage);
favoritesTab.addEventListener('click', showFavoritesPage);

// Initialize
fetchVerse();
showHomePage();
updateFavoritesList(); // Ensure the "No favorites yet!" message is shown initially